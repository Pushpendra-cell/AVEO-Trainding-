export class LoginModel { 
    constructor(
        public name:string,
        public email:string,
        public address?:string
    ){}
}

