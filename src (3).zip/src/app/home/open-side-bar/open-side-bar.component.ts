import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-side-bar',
  templateUrl: './open-side-bar.component.html',
  styleUrls: ['./open-side-bar.component.css']
})
export class OpenSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
