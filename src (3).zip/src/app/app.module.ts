import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { HeaderComponent } from './header/header.component';
import { OpenSideBarComponent } from './home/open-side-bar/open-side-bar.component';

import { ContentComponent } from './content/content.component';
import { CategoryComponent } from './category/category.component';
import { UploadComponent } from './upload/upload.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    OpenSideBarComponent,
    
    ContentComponent,
    CategoryComponent,
    UploadComponent,
   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
